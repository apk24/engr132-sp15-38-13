function errordlgWait(varargin)
uiwait(errordlg(varargin{:}));
end